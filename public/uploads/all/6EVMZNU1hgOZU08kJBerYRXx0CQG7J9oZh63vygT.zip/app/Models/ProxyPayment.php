<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProxyPayment extends Model
{
    protected $table = 'proxypay_payments';
}
